<template>
  <div class="baseline-container">
    <a
      href="https://github.com/frdaria/prompts_for_llama/blob/main/fanfiction2.txt"
      target="_blank"
    >
      https://github.com/frdaria/prompts_for_llama/blob/main/fanfiction2.txt
    </a>
  </div>
</template>

<style>
.baseline-container {
  z-index: 10;
  padding: 5vh;
}
</style>
