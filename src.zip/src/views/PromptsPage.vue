<template>
  <div class="prompts-container">
    <a
      href="https://colab.research.google.com/drive/1pcIPTtmchHuqtXkKvIs9tWDkmhgDwT18?usp=sharing"
      target="_blank"
    >
      https://colab.research.google.com/drive/1pcIPTtmchHuqtXkKvIs9tWDkmhgDwT18?usp=sharing
    </a>
  </div>
</template>

<style>
.prompts-container {
  z-index: 10;
  padding: 5vh;
}
</style>
